import React, { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Router } from "react-router-dom";
import Home from './screens/home.screen';
import Camera from './screens/camera.screen';

import {NextUIProvider} from "@nextui-org/react";

import VideoSampleStream from './screens/video.screen.websocket';

function App() {

  return (
    <NextUIProvider>
   <div className='main-container'>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/camera/:id' element={<Camera/>}/>

        <Route  path='/test' element={<VideoSampleStream/>} />
      </Routes>
   </div>
   </NextUIProvider>
  )
}

export default App