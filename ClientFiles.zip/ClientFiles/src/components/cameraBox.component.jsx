import React ,{useState,useEffect}from 'react'
import { cameraInfo as data } from '../data/camerainfo'
import './cameraBox.component.css'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Link } from 'react-router-dom';
import io from 'socket.io-client';
import Card from 'react-bootstrap/Card';

function CameraBox() {
  const chunkSize = 4;
  const chunkedData = [];
  for (let i = 0; i < data.length; i += chunkSize) {
    chunkedData.push(data.slice(i, i + chunkSize));
  }
  const [detected, setDetected] = useState({0: false, 1: false, 2: false});
  useEffect(() => {
    const socket = io("ws://localhost:7890", {
      transports: ['websocket', 'polling', 'flashsocket']
    });

    socket.on('connect', () => {
      console.log('Connected to the server');
      socket.emit('getinfoCam',{cameraSourceData:[0,2,1]});
    });

    socket.on('object_detected', (data) => {
      setDetected(prevState => ({ ...prevState, [data.camera_id]: true }));
      setTimeout(() => {
        setDetected(prevState => ({ ...prevState, [data.camera_id]: false }));
        
      }, 2000); // Reset color after 2 seconds
    });
   
    socket.on('disconnect', () => {
      console.log('Disconnected from the server');
    });


    
    return () => {
      socket.disconnect();
    };
  }, []);
  return (
    
    <div className="cameraBox-container">

      <Container className='cameraBox-list-container'>
        {chunkedData.map((row, rowIndex) => (
         
          <Row key={rowIndex} className="row">
            {row.map((e, index) => (
              <Link className='LinkToPath' to={`camera/${e.cameraPath}`}>
                 <Card className='Card-Camera' style={{ width: '18rem', backgroundColor:'#c8c8c8c6',boxShadow: detected[0] ? `2px 5px 10px red`: `2px 5px 10px ${e.detectedColor}`}} >
                <Col   key={index}><p>Area : {e.cameraName}</p><p>CameraPath : {e.cameraPath}</p><p>Status : {e.status}</p></Col>
                </Card>
              </Link>
            ))}
           
          </Row>
        

        ))}
      </Container>

    </div>
 
  )
}

export default CameraBox