import React from 'react'

function CameraFrame() {
  return (
    <div>CameraFrame</div>
  )
}

export default CameraFrame