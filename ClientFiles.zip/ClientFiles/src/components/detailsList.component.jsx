import React from 'react'

function DetailsList() {
  return (
    <div>DetailsList</div>
  )
}

export default DetailsList