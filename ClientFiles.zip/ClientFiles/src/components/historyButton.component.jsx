import React from 'react'

function HistoryButton() {
  return (
    <div>HistoryButton</div>
  )
}

export default HistoryButton