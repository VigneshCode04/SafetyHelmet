export const cameraInfo = [
    { "cameraName": "frontCamera", "cameraPath": "0", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": [] ,"status":"Safe"}, 
    { "cameraName": "dockCamera", "cameraPath": "1", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": ["Helmet", "No-vest", "No-mask"] ,"status":"Moderate"}, 
    { "cameraName": "loadCamera", "cameraPath": "2", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": ["Helmet", "No-vest", "No-mask"] ,"status":"Moderate"}, 
    { "cameraName": "portCamera", "cameraPath": "3", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": [] ,"status":"Safe"},
    
    { "cameraName": "frontCamera", "cameraPath": "0", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": [],"status":"Safe" }, 
    { "cameraName": "dockCamera", "cameraPath": "1", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": ["Helmet", "No-vest", "No-mask"],"status":"Risk" }, 
    { "cameraName": "loadCamera", "cameraPath": "2", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": ["Helmet", "No-vest", "No-mask"] ,"status":"Risk"}, 
    { "cameraName": "portCamera", "cameraPath": "3", "annotatedFrame": "", "detectedColor": "#c8c8c8c6", "detectedClasses": [] ,"status":"Safe"}
]


