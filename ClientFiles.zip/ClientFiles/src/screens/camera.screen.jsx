import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import io from 'socket.io-client';

function Camera() {


  const { id } = useParams();
  const ID =parseInt(id)

 
  const [image, setImage] = useState('');

  useEffect(() => {

   
    const socket = io("ws://localhost:7890",
        {transports: ['websocket', 'polling', 'flashsocket']}
        )

    
    socket.on(`frame${ID}`, (data) => {
      setImage(`data:image/jpeg;base64,${data}`);
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from the server');
    });

    return () => {
      socket.disconnect();
    };
  }, [ID]);

  return (
    <div>
      <h1>Camera : {ID}</h1>
      {image && <img src={image} alt={`Camera ${ID}`} />}
    </div>
  );
  
}

export default Camera