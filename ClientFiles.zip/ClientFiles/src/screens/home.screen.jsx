import React from 'react'
import CameraBox from '../components/cameraBox.component'
import './home.screen.css'


function Home() {
  return (
    <div className="MasterComponent">
      <div className="CameraBoxContainer">
        <CameraBox/>
      </div>
      
    </div>
  )
}

export default Home