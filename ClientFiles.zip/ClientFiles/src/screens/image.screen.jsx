import React, { useState, useEffect } from 'react';

const VideoStream = () => {

    return (
        <div>
 
        </div>
    );
};

export default VideoStream;
