import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const VideoSampleStream = () => {
  const [image, setImage] = useState('');
  const [image1, setImage1] = useState('');
  const [image2, setImage2] = useState('');
  const [detected, setDetected] = useState({0: false, 1: false, 2: false});
  const cameraStyle = {
    width: '30rem',
    height: '25rem'
  };

  const containerStyle = {
    display: 'flex',
    justifyContent: 'space-between'
  };

  useEffect(() => {
    const socket = io("ws://localhost:7890", {
      transports: ['websocket', 'polling', 'flashsocket']
    });

    socket.on('connect', () => {
      console.log('Connected to the server');
      socket.emit('getinfoCam');
    });

    socket.on('frame0', (data) => {
      setImage(`data:image/jpeg;base64,${data}`);
    });

    socket.on('frame1', (data) => {
      setImage1(`data:image/jpeg;base64,${data}`);
    });

    socket.on('frame2', (data) => {
      setImage2(`data:image/jpeg;base64,${data}`);
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from the server');
    });


    socket.on('object_detected', (data) => {
      setDetected(prevState => ({ ...prevState, [data.camera_id]: true }));
      setTimeout(() => {
        setDetected(prevState => ({ ...prevState, [data.camera_id]: false }));
      }, 2000); // Reset color after 2 seconds
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
  <div style={containerStyle}>
      <div style={{ border: detected[0] ? '5px solid red' : 'none' }}>
        <h1>Camera 0</h1>
        {image && <img src={image} alt="Camera 0" style={cameraStyle} />}
      </div>
      <div style={{ border: detected[1] ? '5px solid red' : 'none' }}>
        <h1>Camera 1</h1>
        {image1 && <img src={image1} alt="Camera 1" style={cameraStyle} />}
      </div>
      <div style={{ border: detected[2] ? '5px solid red' : 'none' }}>
        <h1>Camera 2</h1>
        {image2 && <img src={image2} alt="Camera 2" style={cameraStyle} />}
      </div>
    </div>
  );
};

export default VideoSampleStream;
