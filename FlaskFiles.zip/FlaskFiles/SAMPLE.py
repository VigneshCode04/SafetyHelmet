import cv2

cap  = cv2.VideoCapture("C:\\Users\\Vignesh R\\React-FlaskTest\\flask-server\\trimVideo1.mp4")

while True:
    rect,frame = cap.read()
    if rect:
        cv2.imshow('Captured Frame',frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        break

# Release the video capture object and close the display window
cap.release()
cv2.destroyAllWindows()
