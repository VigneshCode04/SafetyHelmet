import websockets
import asyncio
import time
import cv2
import base64
import numpy as np
from collections import defaultdict
from ultralytics import YOLO


PORT = 7890
model = YOLO('C://Users//Vignesh R//HDModel//Models//best.pt',verbose=False)
print("Server listening on port "+str(PORT))

connected = set()
track_history = defaultdict(lambda: [])
detectedClass_ids = set()
send_notification = False

async def echo(websocket,path):
    print("A client just connected")
    connected.add(websocket)
    try:
        async for message in websocket:
            print("Recieved message from client :" + message)
            # while True:
            #     print("InLoop")
            #     time.sleep(5)
            #     num = 0 
            #     print("Loop:" + str(num))
            #     await websocket.send("Connected..!")
            #     num =num+ 1
            cap = cv2.VideoCapture('C:\\Users\\Vignesh R\\React-FlaskTest\\flask-server\\trimVideo1.mp4')  # Open the webcam (use appropriate index)
            while cap.isOpened():
                success, frame = cap.read()
                if success:
                    # Run YOLOv8 detection on the frame
                    detections = model.track(frame,classes=[5,2,4,3])
                
                    annotated_frame = detections[0].plot()
                    frame = cv2.resize(annotated_frame, (640, 480))  # Resize the frame
                    _, buffer = cv2.imencode('.jpg', annotated_frame)  # Encode as JPEG
                    jpg_as_text = base64.b64encode(buffer).decode('utf-8')
                    await websocket.send(jpg_as_text)
                    # for box in detections[0].boxes:
                    #     if(box.id!=None):
                    #         className = classNames[int(box.cls[0])]
                    #         objectID = box.id.int().cpu().tolist()
                    #         if(className == 'Person' and objectID[0] not in detectedClass_ids):
                    #             detectedClass_ids.add(objectID[0])
                    #             print(detectedClass_ids)
                    #             print("Class : "+className+"--->"+"ID : ",objectID)
                                # frame = cv2.resize(frame, (640, 480))  # Resize the frame
                                # _, buffer = cv2.imencode('.jpg', frame)  # Encode as JPEG
                                # jpg_as_text = base64.b64encode(buffer).decode('utf-8')
                                # await websocket.send(jpg_as_text)
                else:
                    break
                # print("InLoop")
                
                # ret, frame = camera.read()
                # if not ret:
                #     break
                # frame = cv2.resize(frame, (640, 480))  # Resize the frame
                # _, buffer = cv2.imencode('.jpg', frame)  # Encode as JPEG
                # jpg_as_text = base64.b64encode(buffer).decode('utf-8')
                # await websocket.send(jpg_as_text)
                
                # print(str(jpg_as_text))
   
    except websockets.exceptions.ConnectionClosed as e:
        print("A client just disconnected from server")    
start_server = websockets.serve(echo,"localhost",PORT)

asyncio.get_event_loop().run_until_complete(start_server)

asyncio.get_event_loop().run_forever()