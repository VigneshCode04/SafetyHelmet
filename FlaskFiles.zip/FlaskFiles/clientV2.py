from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import cv2
import base64
import numpy as np
from ultralytics import YOLO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'

socketio = SocketIO(app, cors_allowed_origins="*")



model = YOLO('C://Users//Vignesh R//HDModel//Models//best.pt', verbose=False)

def getCameraPath(input):
    if(input == 1):
        return "C:\\Users\\Vignesh R\\React-FlaskTest\\flask-server\\trimVideo1.mp4"
    if(input == 0):
        return 0
@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('cameranInfo')
def getCameraInfo():
    print("Hello Camera")
    emit('info',"Helo Sample Details")

@socketio.on('request_frame')
def handle_request_frame(data):
    camera_path = data.get('cameraId')
    print(camera_path)

    input_path = getCameraPath(int(camera_path))
    cap = cv2.VideoCapture(input_path)  # Use 0 for webcam or provide video file path
    while cap.isOpened():
        success, frame = cap.read()
        if success:
            detections = model.track(frame, classes=[5, 2, 4, 3])
            annotated_frame = detections[0].plot()
            _, buffer = cv2.imencode('.jpg', annotated_frame)
            jpg_as_text = base64.b64encode(buffer).decode('utf-8')
            emit('frame', jpg_as_text)
        else:
            break
    cap.release()

if __name__ == '__main__':
    socketio.run(app, "localhost", port=7890)
