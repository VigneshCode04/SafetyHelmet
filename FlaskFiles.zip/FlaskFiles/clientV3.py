from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import cv2
import base64
import numpy as np
from ultralytics import YOLO
import threading
import time
import asyncio

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'

socketio = SocketIO(app, cors_allowed_origins="*")
thread_collection = []
# Initialize the YOLO model once
model = YOLO('C://Users//Vignesh R//HDModel//Models//best.pt', verbose=False)

def getCameraPath(input):
    if input == 1:
        return "C:\\Users\\Vignesh R\\React-FlaskTest\\flask-server\\trimVideo1.mp4"
    elif input == 0:
        return 0
    elif input == 2:
        return "C:\\Users\\Vignesh R\\HDModel\\Models\\ship.mp4"

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

testDictonary = {'camera1':"",'camera3':"",'camera2':""}

class CameraThread(threading.Thread):
    def __init__(self, cam_id, source,model):
        threading.Thread.__init__(self)
        self.cam_id = cam_id
        self.source = source
        self.model = model
        print(id(self.model))

    def run(self):
        cap = cv2.VideoCapture(self.cam_id)
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(fps) 
        frame_count = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                print(f"Failed to read frame from camera {self.source}")
                break
            if frame_count % frame_interval == 0:
                self.result = self.model.track(frame,classes=[2,3])
                self.annotated_frame = self.result[0].plot()
                _, buffer = cv2.imencode('.jpg', self.annotated_frame)
                self.jpg_as_text = base64.b64encode(buffer).decode('utf-8')
                print(f"Emitting frame for camera {self.source}")

                socketio.emit(f'frame{self.source}', self.jpg_as_text, namespace='/')
                if len(self.result[0].boxes) > 0:
                    socketio.emit('object_detected', {'camera_id': self.source}, namespace='/')
            # if ret:
            #     # Convert OpenCV frame to PhotoImage
            #     self.result = self.model.track(frame)
            #     self.annotated_frame = self.result[0].plot()
            #     # self.img = Image.fromarray(cv2.cvtColor(self.annotated_frame, cv2.COLOR_BGR2RGB))
            #     _, buffer = cv2.imencode('.jpg', self.annotated_frame)
            #     self.jpg_as_text = base64.b64encode(buffer).decode('utf-8')
            #     emit(f'frame{self.source}', self.jpg_as_text)
            frame_count += 1
            time.sleep(1 / fps)


@socketio.on('getinfoCam')
def get_details(data):
    global model
    sources = data.get('cameraSourceData') # Replace with your video sources
    for source in sources:
        print('Creating thread for source:', source)
        input_path = getCameraPath(source)
        thread = CameraThread(cam_id=input_path, source = source,model=YOLO('C://Users//Vignesh R//HDModel//Models//best.pt', verbose=False))
        thread.start()
        thread_collection.append(thread)
        
    return "Started video streams"

if __name__ == '__main__':
    socketio.run(app, "localhost", port=7890, use_reloader=False, debug=True)
