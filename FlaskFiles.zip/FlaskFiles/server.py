from flask import Flask,send_file
import cv2 
import io

app = Flask(__name__)


@app.route("/members")
def members():
    return{"members":["Member1","Member2","Member3"]}

@app.route("/camera1")
def camera():
    count = 0
    while True:
        count +=count
        if(count/2 == 0):

            return{"cameraName": "frontDock","cameraPath": "0","AnnotatedFrame": "https://miro.medium.com/v2/resize:fit:2400/0*hDAyhnOx767w5qma.jpg"}
        else:
            return{"cameraName": "MainCam","cameraPath": "1","AnnotatedFrame": "https://marketingaccesspass.com/wp-content/uploads/2015/10/Podcast-Website-Design-Background-Image.jpg"}

@app.route("/camera2")
def camera1():
    return{"cameraName": "MainCam","cameraPath": "1","AnnotatedFrame": "https://marketingaccesspass.com/wp-content/uploads/2015/10/Podcast-Website-Design-Background-Image.jpg"}

@app.route('/get_frame', methods=['GET'])
def get_frame():
    cap = cv2.VideoCapture("http://192.168.143.188:4747/video.jpg")
    success, frame = cap.read()
    if success:
        _, buffer = cv2.imencode('.jpg', frame)
        return send_file(io.BytesIO(buffer), mimetype='image/jpeg')
    else:
        return "Error capturing frame", 500


if __name__ == "__main__":
    app.run(debug=True)


    