from flask import Flask, render_template
import asyncio
import websockets
import base64
import cv2

app = Flask(__name__)
PORT = 8080

connected = set()

@app.route('/')
def index():
    return render_template('index.html')


async def send_frames(websocket, path):
    print("A client just connected")
    connected.add(websocket)
    try:
        async for message in websocket:
            print("Recieved message from client :" + message)
        camera = cv2.VideoCapture('C:\\Users\\Vignesh R\\React-FlaskTest\\flask-server\\trimVideo1.mp4')  # Open the webcam (use appropriate index)
        while True:
            ret, frame = camera.read()
            if not ret:
                break
            frame = cv2.resize(frame, (640, 480))  # Resize the frame
            _, buffer = cv2.imencode('.jpg', frame)  # Encode as JPEG
            jpg_as_text = base64.b64encode(buffer).decode('utf-8')
            await websocket.send(jpg_as_text)

    except websockets.exceptions.ConnectionClosed as e:
        print("A client just disconnected from server")    
start_server = websockets.serve(send_frames,"localhost",PORT)



   
if __name__ == '__main__':
    app.run(debug=True)
      